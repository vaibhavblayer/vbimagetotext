from .main import main
main(prog_name="vbimagetotext")
